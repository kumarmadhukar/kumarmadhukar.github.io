

square :: Int -> Int
square x = x * x

squareAll :: [Int] -> [Int]
-- squareAll [] = []
-- squareAll (x:xs) = (square x):(squareAll xs)
squareAll = map square

