
merge :: [Int] -> [Int] -> [Int]
merge l [] = l
merge [] l = l
merge (x:xs) (y:ys)
  | (x < y) = x:(merge xs (y:ys))
  | otherwise = y:(merge (x:xs) ys)

mergeSort :: [Int] -> [Int]
mergeSort [] = []
mergeSort [x] = [x]
mergeSort l = merge (mergeSort (fsthalf l)) (mergeSort (sndhalf l))
   where
   fsthalf l = take (div (length l) 2) l
   sndhalf l = drop (div (length l) 2) l

