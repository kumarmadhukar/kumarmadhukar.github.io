
checkElem :: (Eq a) => a -> [a] -> Bool
checkElem x [] = False
checkElem x (y:ys)
   | (x == y) = True
   | otherwise = (checkElem x ys)

