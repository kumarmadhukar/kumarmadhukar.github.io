

listlen :: [c] -> Int
listlen [] = 0
listlen (x:xs) = 1 + (listlen xs)


mymap :: (a->b) -> [a] -> [b]
mymap f [] = []
mymap f (x:xs) = (f x):(mymap f xs)

revlist :: [a] -> [a]
revlist [] = []
revlist (x:xs) = (revlist xs) ++ [x]

cc :: [[a]] -> [a]
cc [] = []
cc (x:xs) = x ++ (cc xs)
