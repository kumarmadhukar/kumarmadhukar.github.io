
-- (x,y) (a tuple of typle (Float, Float)) is a point in two-dimensional space

square :: Float -> Float
square x = x*x*2

distance :: (Float, Float) -> (Float, Float) -> Float
distance (x1,y1) (x2,y2) = 
  let xdiff = (x2-x1)
      ydiff = (y2-y1)
      square x = x * x
  in sqrt ((square xdiff) + (square ydiff))



