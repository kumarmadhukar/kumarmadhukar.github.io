
isEven :: Int -> Bool
isEven x = (mod x 2 == 0)

getEvens :: [Int] -> [Int]
getEvens = filter isEven 
-- getEvens [] = []
-- getEvens (x:xs)
--   | (isEven x) = x:(getEvens xs)
--   | otherwise = (getEvens xs)

