
# sum of a*r^0 + a*r^1 + a*r^2 + ... up to n terms

a = 2
r = 3
n = 5

gpsum = 0;

for i in range(0, n):
	#print(f"{i}")
	p = 1
	for j in range(0, i):
		#print(f"{i} {j}")
		p = p*r

	currTerm = a*p
	gpsum = gpsum + currTerm

print(f"{gpsum}")



