
# sum of a*r^0 + a*r^1 + a*r^2 + ... up to n terms

a = 2
r = 3
n = 5

lastTerm = a
gpsum = a

for i in range(1, n):
	currTerm = lastTerm*r
	gpsum = gpsum + currTerm
	lastTerm = currTerm

print(f"{gpsum}")

