
# Akash, Baadal and Chanda are selling tickets for a fundraising event.
# Baadal sold two tickets fewer than Akash.
# Chanda sells twice as many tickets as Akash.
# Together the three of them sell 10 tickets in total.
# How many tickets did Akash sell?


# let a be the number of tickets sold by Akash
# let b be the number of tickets sold by Baadal
# let c be the number of tickets sold by Chanda


for a in range (0, 11):
	for b in range (0, 11):
		for c in range (0, 11):
			#print(f"{a}   {b}    {c}")

			# C1: Baadal sells 2 tickets fewer than Akash
			fstcond = 0
			if(b == a-2):
				fstcond = 1
			
			# C2: Chanda sells twice the number of tickets as Akash

			sndcond = 0
			if(c == 2*a):
				sndcond = 1
	
			# C3: together they sell 10 tickets

			trdcond = 0
			if(a+b+c == 10):
				trdcond = 1
			

			if(fstcond and sndcond and trdcond):
				print(f"{a}   {b}    {c}")
			
				


