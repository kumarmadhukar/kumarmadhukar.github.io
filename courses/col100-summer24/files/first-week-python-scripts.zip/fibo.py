
# Fibonacci sequence
# 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, ...
# code to print the first n terms (iterative)


fstTerm = 0
sndTerm = 1

n = 25

print(f"{fstTerm}")
print(f"{sndTerm}")

i = 2;

lTerm = sndTerm
llTerm = fstTerm

while(i < n):
	currTerm = lTerm + llTerm
	print(f"{currTerm}")
	llTerm = lTerm
	lTerm = currTerm
	i = i + 1


