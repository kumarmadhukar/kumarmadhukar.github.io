
# Fibonacci sequence
# 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, ...
# code to print the first n terms (recursive)

def find_ith_term(i):
	if(i <= 0):
		return 0
	if(i == 1):
		return 1
	else:
		return(find_ith_term(i-1) + find_ith_term(i-2))


n = 25
i = 0

while(i < n):
	v = find_ith_term(i)
	print(f"{v}")
	i = i + 1


	
