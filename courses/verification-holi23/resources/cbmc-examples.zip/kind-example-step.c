
int nondet_int();

void main(void)
{
	int n;
	int x = 0;
	int i = nondet_int();
	int temp;
	int a = nondet_int();
	int b = nondet_int();
	int c = nondet_int();

	__CPROVER_assume(i < n);
	__CPROVER_assume(a != b);
	temp = a;
	a = b;
	b = c;
	c = temp;
	i++;
	
	__CPROVER_assume(i < n);
	__CPROVER_assume(a != b);
	temp = a;
	a = b;
	b = c;
	c = temp;
	i++;

	__CPROVER_assume(i < n);
	__CPROVER_assume(a != b);
	temp = a;
	a = b;
	b = c;
	c = temp;
	i++;

	__CPROVER_assume(i < n);
	__CPROVER_assert(a != b, "test");
	temp = a;
	a = b;
	b = c;
	c = temp;
	i++;
}


		
