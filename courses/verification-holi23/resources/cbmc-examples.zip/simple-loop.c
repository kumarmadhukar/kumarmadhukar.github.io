
void main(void){

	int x = 0;
	int n;
	int i;

	while(i < n){
		x = x + 1;
		i++;
	}

	__CPROVER_assert(x < 5, "test");
}

