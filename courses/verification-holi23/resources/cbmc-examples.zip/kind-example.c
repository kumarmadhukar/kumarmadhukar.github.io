
void main(void)
{
	int n;
	int x = 0;
	int i = 0;
	int temp;
	int a = 1;
	int b = 2;
	int c = 3;

	while (i < n) {
		__CPROVER_assert(a != b, "test");
		// (a!=b) /\ (b!=c) /\ (c!=a)  is an inductive invariant of the loop
		temp = a;
		a = b;
		b = c;
		c = temp;
		i++;
	}
}


		
