
void main(void)
{
	int n;
	int x = 0;
	int i = 0;
	int temp;
	int a = 1;
	int b = 2;
	int c = 3;

	__CPROVER_assume(i < n);
	__CPROVER_assert(a != b, "test");
	temp = a;
	a = b;
	b = c;
	c = temp;
	i++;
	
	__CPROVER_assume(i < n);
	__CPROVER_assert(a != b, "test");
	temp = a;
	a = b;
	b = c;
	c = temp;
	i++;
	
	__CPROVER_assume(i < n);
	__CPROVER_assert(a != b, "test");
	temp = a;
	a = b;
	b = c;
	c = temp;
	i++;

	__CPROVER_assume(i < n);
	__CPROVER_assert(a != b, "test");
	temp = a;
	a = b;
	b = c;
	c = temp;
	i++;
}


		
