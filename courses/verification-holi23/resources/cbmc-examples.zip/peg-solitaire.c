
extern unsigned int nondet_uint();

void main(void){

	unsigned int board[7][7];
	unsigned int moves = 0;
	unsigned int srcx;
	unsigned int srcy;
	unsigned int tgtx;
	unsigned int tgty;
	unsigned int midx;
	unsigned int midy;

	for(unsigned int i = 0; i <= 6; i++) {
		for(unsigned int j = 0; j <= 6; j++) {
			board[i][j] = 1;
		}
	}
	
	board[3][3] = 0;

	//non-playing region of the board
	board[0][0] = 2; board[0][1] = 2; board[0][5] = 2; board[0][6] = 2;
	board[1][0] = 2; board[1][1] = 2; board[1][5] = 2; board[1][6] = 2;
	board[5][0] = 2; board[5][1] = 2; board[5][5] = 2; board[5][6] = 2;
	board[6][0] = 2; board[6][1] = 2; board[6][5] = 2; board[6][6] = 2;

	while(1){
		__CPROVER_assert(moves <= 25, "game");
		
		srcx = nondet_uint();
		srcy = nondet_uint();
		tgtx = nondet_uint();
		tgty = nondet_uint();

		__CPROVER_assume((srcx >= 0) && (srcx <= 6));
		__CPROVER_assume((srcy >= 0) && (srcy <= 6));
		__CPROVER_assume((tgtx >= 0) && (tgtx <= 6));
		__CPROVER_assume((tgty >= 0) && (tgty <= 6));
		
		__CPROVER_assume(((srcx == tgtx) && ((tgty - srcy == 2) || (tgty - srcy == -2)))|| ((srcy == tgty) && ((tgtx - srcx == 2) || (tgtx - srcx == -2))));

		midx = (srcx + tgtx)/2;
		midy = (srcy + tgty)/2;
		
		__CPROVER_assume((board[srcx][srcy] == 1) && (board[tgtx][tgty] == 0) && (board[midx][midy] == 1));

		board[srcx][srcy] = 0;
		board[tgtx][tgty] = 1;
		board[midx][midy] = 0;
		moves++;
	}
}





