
extern unsigned int nondet_uint();

// let -1 denote the left bank and 1 denote the right bank

void main(void){

  int goat = -1;
  int wolf = -1;
  int cabbage = -1;
  int man = -1;

  int danger = 0;
  int steps = 0;

  while(steps < 7){

	
	int carry = nondet_uint();
	__CPROVER_assume((carry >= 0) && (carry <= 3));

	// carry 0 denotes man goes alone
	// carry 1 denotes man takes goat
	// carry 2 denotes man takes wolf
	// carry 3 denotes man takes cabbage

	if(carry == 0){ man = man * -1;}
	if(carry == 1){ man = man * -1; goat = goat * -1; }
	if(carry == 2){ man = man * -1; wolf = wolf * -1; }
	if(carry == 3){ man = man * -1; cabbage = cabbage * -1; }
	
	if((goat == cabbage) && (goat != man)){ danger = 1; }
	if((goat == wolf) && (goat != man)){ danger = 1; }
		
	__CPROVER_assume(danger == 0);
	steps++;

	__CPROVER_assert(((man != 1)||(goat != 1)||(wolf != 1)||(cabbage != 1)), "crossed");

  }
  
  return;
}





